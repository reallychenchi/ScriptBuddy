# README

**asr tob 相关client demo**

# Notice
python version: python 3.x

替换代码中的key为真实数据:
    "app_key": "xxxxxxx",
    "access_key": "xxxxxxxxxxxxxxxx"
使用示例：
    python3 sauc_websocket_demo.py --file /Users/bytedance/code/python/eng_ddc_itn.wav



